from .test import *

name = "test"

__all__ = {
    'test',
}
